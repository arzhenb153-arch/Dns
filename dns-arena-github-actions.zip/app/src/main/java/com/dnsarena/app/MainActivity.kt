package com.dnsarena.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var pendingDns1: String? = null
    private var pendingDns2: String? = null

    companion object {
        private const val VPN_REQUEST_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {

        // فراخوانی از داخل صفحه وب وقتی کاربر دکمه «اتصال» را می‌زند
        @JavascriptInterface
        fun connectDns(dns1: String, dns2: String) {
            pendingDns1 = dns1
            pendingDns2 = dns2

            val prepareIntent = VpnService.prepare(this@MainActivity)
            runOnUiThread {
                if (prepareIntent != null) {
                    // سیستم دیالوگ استاندارد "درخواست اتصال VPN" اندروید را نشان می‌دهد
                    startActivityForResult(prepareIntent, VPN_REQUEST_CODE)
                } else {
                    startVpn()
                }
            }
        }

        @JavascriptInterface
        fun disconnectDns() {
            stopService(Intent(this@MainActivity, DnsVpnService::class.java))
            runOnUiThread {
                webView.evaluateJavascript("window.setVpnStatus && setVpnStatus('idle')", null)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                startVpn()
            } else {
                webView.evaluateJavascript("window.setVpnStatus && setVpnStatus('denied')", null)
            }
        }
    }

    private fun startVpn() {
        val intent = Intent(this, DnsVpnService::class.java)
        intent.putExtra("dns1", pendingDns1)
        intent.putExtra("dns2", pendingDns2)
        startService(intent)
        webView.evaluateJavascript("window.setVpnStatus && setVpnStatus('connected')", null)
    }
}
