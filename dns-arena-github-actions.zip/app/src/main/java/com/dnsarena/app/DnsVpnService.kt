package com.dnsarena.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * سرویس VPN واقعی. هیچ ترافیک عمومی‌ای را دست‌کاری نمی‌کند —
 * فقط بسته‌های DNS (UDP روی پورت ۵۳) که مقصدشان سرورهای انتخابی
 * کاربر است از رابط tun می‌گیرد، به سرور واقعی DNS می‌فرستد،
 * و پاسخ را به همان برنامه‌ی درخواست‌دهنده برمی‌گرداند.
 */
class DnsVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    @Volatile private var running = false
    private var workerThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dns1 = intent?.getStringExtra("dns1") ?: "1.1.1.1"
        val dns2 = intent?.getStringExtra("dns2")
        startVpn(dns1, dns2)
        return START_STICKY
    }

    private fun startVpn(dns1: String, dns2: String?) {
        stopVpn() // اگر قبلاً چیزی وصل بود، اول تمیز کن

        val builder = Builder()
            .setSession("DNS Arena")
            .addAddress("10.10.10.2", 32)
            .addDnsServer(dns1)
            .addRoute(dns1, 32)
            .setMtu(1500)

        if (!dns2.isNullOrBlank()) {
            builder.addDnsServer(dns2)
            builder.addRoute(dns2, 32)
        }

        vpnInterface = builder.establish() ?: return
        running = true
        workerThread = Thread { runLoop() }.also { it.start() }
    }

    private fun runLoop() {
        val iface = vpnInterface ?: return
        val input = FileInputStream(iface.fileDescriptor)
        val output = FileOutputStream(iface.fileDescriptor)
        val buffer = ByteArray(32767)

        while (running) {
            val length = try {
                input.read(buffer)
            } catch (e: Exception) {
                break
            }
            if (length <= 0) continue
            val packet = buffer.copyOf(length)
            // هر بسته DNS را در یک ترد جدا هندل کن تا چند درخواست هم‌زمان بلاک نشوند
            Thread { handlePacket(packet, output) }.start()
        }
    }

    private fun handlePacket(packet: ByteArray, output: FileOutputStream) {
        try {
            if (packet.size < 28) return
            val ihl = (packet[0].toInt() and 0x0F) * 4
            val protocol = packet[9].toInt() and 0xFF
            if (protocol != 17) return // فقط UDP

            val srcIp = packet.copyOfRange(12, 16)
            val dstIp = packet.copyOfRange(16, 20)
            val udpStart = ihl

            val srcPort = ((packet[udpStart].toInt() and 0xFF) shl 8) or (packet[udpStart + 1].toInt() and 0xFF)
            val dstPort = ((packet[udpStart + 2].toInt() and 0xFF) shl 8) or (packet[udpStart + 3].toInt() and 0xFF)
            val udpLen = ((packet[udpStart + 4].toInt() and 0xFF) shl 8) or (packet[udpStart + 5].toInt() and 0xFF)

            val payloadStart = udpStart + 8
            val payloadLen = udpLen - 8
            if (payloadLen <= 0 || payloadStart + payloadLen > packet.size) return
            val dnsQuery = packet.copyOfRange(payloadStart, payloadStart + payloadLen)

            val destAddress = InetAddress.getByAddress(dstIp)

            val socket = DatagramSocket()
            protect(socket) // مهم: تا خود این ترافیک دوباره وارد tun نشود
            socket.soTimeout = 4000
            socket.send(DatagramPacket(dnsQuery, dnsQuery.size, destAddress, dstPort))

            val respBuf = ByteArray(4096)
            val respPacket = DatagramPacket(respBuf, respBuf.size)
            socket.receive(respPacket)
            socket.close()

            val reply = buildIpv4UdpPacket(
                srcIp = dstIp, dstIp = srcIp,
                srcPort = dstPort, dstPort = srcPort,
                payload = respPacket.data.copyOf(respPacket.length)
            )
            synchronized(output) {
                output.write(reply)
            }
        } catch (e: Exception) {
            // بسته ناقص یا بدون پاسخ؛ نادیده بگیر
        }
    }

    private fun buildIpv4UdpPacket(
        srcIp: ByteArray, dstIp: ByteArray,
        srcPort: Int, dstPort: Int, payload: ByteArray
    ): ByteArray {
        val udpLen = 8 + payload.size
        val totalLen = 20 + udpLen
        val packet = ByteArray(totalLen)

        packet[0] = 0x45
        packet[2] = ((totalLen shr 8) and 0xFF).toByte()
        packet[3] = (totalLen and 0xFF).toByte()
        packet[6] = 0x40.toByte()
        packet[8] = 64
        packet[9] = 17
        System.arraycopy(srcIp, 0, packet, 12, 4)
        System.arraycopy(dstIp, 0, packet, 16, 4)

        var sum = 0
        var i = 0
        while (i < 20) {
            val word = ((packet[i].toInt() and 0xFF) shl 8) or (packet[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val checksum = sum.inv() and 0xFFFF
        packet[10] = ((checksum shr 8) and 0xFF).toByte()
        packet[11] = (checksum and 0xFF).toByte()

        val udpStart = 20
        packet[udpStart] = ((srcPort shr 8) and 0xFF).toByte()
        packet[udpStart + 1] = (srcPort and 0xFF).toByte()
        packet[udpStart + 2] = ((dstPort shr 8) and 0xFF).toByte()
        packet[udpStart + 3] = (dstPort and 0xFF).toByte()
        packet[udpStart + 4] = ((udpLen shr 8) and 0xFF).toByte()
        packet[udpStart + 5] = (udpLen and 0xFF).toByte()
        // چک‌سام UDP صفر گذاشته شده (طبق RFC768 برای IPv4 مجاز است)
        System.arraycopy(payload, 0, packet, udpStart + 8, payload.size)

        return packet
    }

    private fun stopVpn() {
        running = false
        workerThread?.interrupt()
        workerThread = null
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            // نادیده بگیر
        }
        vpnInterface = null
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
